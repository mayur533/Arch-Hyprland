#!/bin/bash

WALL_DIR="$HOME/.config/swww/Wallpapers"
CONFIG_FILE="$HOME/.config/swww/scripts/settings.json"
CUR="$WALL_DIR/current.jpg"
PREV="$WALL_DIR/prev.jpg"
NEXT="$WALL_DIR/next.jpg"

mkdir -p "$WALL_DIR"--

mode=$(jq -r '.selected.mode' "$CONFIG_FILE")
selected_source=$(jq -r '.selected.source' "$CONFIG_FILE")
selected_category=$(jq -r '.selected.category' "$CONFIG_FILE")
api_key_unsplash=$(jq -r '.api_keys.unsplash' "$CONFIG_FILE")
api_key_wallhaven=$(jq -r '.api_keys.wallhaven' "$CONFIG_FILE")
sources=($(jq -r '.sources[]' "$CONFIG_FILE"))
transitions=($(jq -r '.transitions[]' "$CONFIG_FILE"))

get_random_transition() {
    echo "${transitions[RANDOM % ${#transitions[@]}]}"
}

apply_wallpaper() {
    local transition=$(get_random_transition)
    if [[ -f "$CUR" && -s "$CUR" ]]; then
        echo "🎨 Applying wallpaper with transition: $transition"
        swww img "$CUR" --transition-type "$transition" --transition-step 90

        echo "🎨 Extracting color palette with pywal + haishoku..."
        rm -rf ~/.cache/wal
        wal -i "$CUR" --backend haishoku --saturate 0.7 -e &>/dev/null

        echo "🔗 Refreshing symlinks..."
        ln -sf ~/.cache/wal/colors-waybar.css ~/.config/waybar/colors.css
        ln -sf ~/.cache/wal/colors-kitty.conf ~/.config/kitty/pywal.conf
        ln -sf ~/.cache/wal/colors-wofi.css ~/.config/wofi/colors.css

        echo "✅ Theme applied to: Waybar, Kitty, Wofi, Shell"

        echo "🎨 Dominant Colors:"
        jq -r '.colors.special' ~/.cache/wal/colors.json | while IFS="=" read -r k v; do
            echo "$k: $v"
        done
        jq -r '.colors.colors' ~/.cache/wal/colors.json | while IFS="=" read -r k v; do
            echo "$k: $v"
        done | head -n 8

        # ✅ Update Waybar theme
        echo "🎨 Updating Waybar style..."
        bash ~/.config/waybar/scripts/style-waybar.sh
    else
        echo "⚠️ No valid current wallpaper to apply."
    fi
}

download_from_unsplash() {
    local out_file="$1"
    local url="https://api.unsplash.com/photos/random?orientation=landscape&query=$selected_category&client_id=$api_key_unsplash"
    local img_url=$(curl -s "$url" | jq -r '.urls.full')
    [[ "$img_url" != "null" ]] && curl -sL "$img_url" --output "$out_file" --retry 3 --retry-delay 2
}

download_from_wallhaven() {
    local out_file="$1"
    local url="https://wallhaven.cc/api/v1/search?q=$selected_category&sorting=random&purity=100&apikey=$api_key_wallhaven"
    local img_url=$(curl -s "$url" | jq -r '.data[0].path')
    [[ "$img_url" != "null" ]] && curl -sL "$img_url" --output "$out_file" --retry 3 --retry-delay 2
}

download_wallpaper() {
    local out_file="$1"

    try_source() {
        case "$1" in
            unsplash)
                echo "🌄 Downloading from Unsplash..."
                download_from_unsplash "$out_file" && [[ -s "$out_file" ]] && return 0
                ;;
            wallhaven)
                echo "🖼️ Downloading from Wallhaven..."
                download_from_wallhaven "$out_file" && [[ -s "$out_file" ]] && return 0
                ;;
        esac
    }

    try_source "$selected_source" && return

    for src in "${sources[@]}"; do
        [[ "$src" == "$selected_source" ]] && continue
        try_source "$src" && return
    done

    echo "❌ All wallpaper sources failed."
    return 1
}

case "$1" in
    init)
        echo "🔄 Initializing wallpaper setup..."
        [[ -f "$CUR" && -s "$CUR" ]] || download_wallpaper "$CUR"
        [[ -f "$NEXT" && -s "$NEXT" ]] || download_wallpaper "$NEXT"
        apply_wallpaper
        ;;

    next)
        echo "➡️ Switching to next wallpaper..."
        mv -f "$CUR" "$PREV"
        mv -f "$NEXT" "$CUR"
        download_wallpaper "$NEXT"
        apply_wallpaper
        ;;

    prev)
        if [[ -f "$PREV" && -s "$PREV" ]]; then
            echo "⬅️ Switching to previous wallpaper..."
            mv -f "$CUR" "$NEXT"
            mv -f "$PREV" "$CUR"
            download_wallpaper "$PREV"
            apply_wallpaper
        else
            echo "⚠️ No previous wallpaper available."
        fi
        ;;

    *)
        echo "Usage: $0 {init|next|prev}"
        ;;
esac
