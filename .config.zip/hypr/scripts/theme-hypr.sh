#!/bin/bash

 # generate pywal theme
ln -sf ~/.cache/wal/colors ~/.config/hypr/pywal-colors

hyprctl reload
