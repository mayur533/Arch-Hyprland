#!/bin/bash

# Coordinates for Bahul, Pune (adjust if needed)
LAT="18.52"
LON="73.85"

# Get weather data
weather_data=$(curl -s "wttr.in/~$LAT,$LON?format=%l:+%c+%t+%w")
temperature=$(curl -s "wttr.in/~$LAT,$LON?format=%t" | sed 's/+//')

if [ -z "$temperature" ]; then
    echo '{"text": " N/A", "tooltip": "Weather unavailable", "class": "weather unavailable"}'
else
    echo "{\"text\": \" $temperature\", \"tooltip\": \"$weather_data\", \"class\": \"weather available\"}"
fi