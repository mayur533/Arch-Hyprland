#!/bin/bash

# === Activate Python Env ===
source /home/mayur/.venvs/pywalenv/bin/activate

# === Convert HEX to RGB ===
hex_to_rgb() {
    hex="${1#"#"}"
    r=$(printf "%d" 0x${hex:0:2})
    g=$(printf "%d" 0x${hex:2:2})
    b=$(printf "%d" 0x${hex:4:2})
    echo "$r, $g, $b"
}

# === Pywal Check ===
WAL_COLORS="$HOME/.cache/wal/colors"
WALLPAPER=$(cat "$HOME/.cache/wal/wal" 2>/dev/null)

if [ ! -f "$WAL_COLORS" ] || [ ! -f "$WALLPAPER" ]; then
    echo "⚠️ Error: Pywal colors or wallpaper not found. Run 'wal' first."
    exit 1
fi

# === Read Pywal Colors ===
mapfile -t colors < "$WAL_COLORS"

# === Named Pywal Colors ===
color0="${colors[0]}"   # background
color1="${colors[1]}"   # red
color2="${colors[2]}"   # green
color3="${colors[3]}"   # yellow
color4="${colors[4]}"   # blue
color5="${colors[5]}"   # magenta
color6="${colors[6]}"   # cyan
color7="${colors[7]}"   # light gray
color8="${colors[8]}"   # gray
color9="${colors[9]}"   # light red
color10="${colors[10]}" # light green
color11="${colors[11]}" # light yellow
color12="${colors[12]}" # light blue
color13="${colors[13]}" # light magenta
color14="${colors[14]}" # light cyan
color15="${colors[15]}" # foreground

# === Extract colors from image palette ===
read -r highlight hover urgent <<< $(python3 <<EOF
from colorthief import ColorThief
img_path = "$WALLPAPER"

def to_hex(rgb): return '#{:02x}{:02x}{:02x}'.format(*rgb)

try:
    palette = ColorThief(img_path).get_palette(color_count=6)
    highlight = palette[0]
    hover = palette[1]
    urgent = palette[2]
except:
    highlight, hover, urgent = (255,255,255), (200,200,200), (255,80,80)

print(to_hex(highlight), to_hex(hover), to_hex(urgent))
EOF
)

# === Convert to RGBA ===
rgba() {
    echo "rgba($(hex_to_rgb "$1"), $2)"
}

bg_rgba=$(rgba "$color0" 0.2)
bg_secondary_rgba=$(rgba "$color8" 0.3)
highlight_rgba=$(rgba "$highlight" 0.9)
hover_rgba=$(rgba "$hover" 0.3)
urgent_rgba=$(rgba "$urgent" 0.6)
tooltip_rgba=$(rgba "$color0" 0.95)
dark_rgba=$(rgba "$color13" 0.65)
light_rgba=$(rgba "$color7" 0.2)

# === Write Waybar CSS ===
cat > "$HOME/.config/waybar/style.css" <<EOF
/* ===== Base Styles ===== */
* {
    all: unset;
    font-family: 
        'SF Pro Text', 
        'SF Pro Display',
        'JetBrainsMono Nerd Font', 
        'JetBrainsMono Nerd Font Propo',
        'FiraCode Nerd Font',
        'Font Awesome 6 Free',
        'Font Awesome 5 Free',
        'Material Design Icons',
        'Noto Sans',
        'DejaVu Sans',
        sans-serif;
    font-size: 13px;
    font-weight: bold;
}

window#waybar {
    background-color: transparent;
    color: ${color15};
}

/* ===== Modules ===== */
#custom-media,
#custom-weather,
#clock,
#battery,
#network,
#pulseaudio,
#backlight,
#power-profiles-daemon,
#tray {
    padding: 0 12px;
    margin: 0 2px;
    border-radius: 8px;
    background-color: ${bg_secondary_rgba};
    color: ${color15};
}

/* ===== States ===== */
#custom-media.playing,
#custom-weather.available,
#battery.charging,
#power-profiles-daemon.power-saver {
    background-color: ${highlight_rgba};
}

#custom-media.paused {
    background-color: ${hover_rgba};
}

#custom-media.no-media,
#custom-weather.unavailable,
#network.disconnected,
#pulseaudio.volume-100,
#battery.critical,
#power-profiles-daemon.performance {
    background-color: ${urgent_rgba};
    animation: blink 2s infinite;
}

/* ===== Workspaces ===== */
#workspaces button {
    padding: 0 8px;
    margin-left: 3px;
    border-radius: 6px;
    background-color: ${bg_rgba};
    color: ${color15};
}

#workspaces button.active {
    background-color: ${highlight_rgba};
    color: ${color15};
}

#workspaces button:not(.empty):not(.active):not(.urgent):not(:hover) {
    background-color: ${dark_rgba};
    color: ${color15};
}

#workspaces button.urgent {
    background-color: ${urgent_rgba};
}

#workspaces button:hover {
    background-color: ${hover_rgba};
}

/* ===== Animations ===== */
@keyframes blink {
    0% { background-color: ${urgent_rgba}; }
    50% { background-color: rgba($(hex_to_rgb "$urgent"), 0.15); }
    100% { background-color: ${urgent_rgba}; }
}

/* ===== Tooltip ===== */
tooltip {
    background: ${tooltip_rgba};
    border-radius: 8px;
    padding: 8px;
    color: ${color7};
}

tooltip label {
    color: inherit;
}
EOF

# === Relaunch Waybar ===
killall waybar 2>/dev/null
(sleep 0.3 && nohup waybar >/dev/null 2>&1 &) &

echo "✅ Full Waybar theme applied using all pywal colors + wallpaper palette."
