#!/bin/bash

player="playerctl"

is_playing=$($player status 2>/dev/null)

if [ "$is_playing" == "Playing" ]; then
    $player pause
elif [ "$is_playing" == "Paused" ]; then
    $player play
else
    $player play
fi
