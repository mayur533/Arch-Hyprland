#!/bin/bash

# Check if waybar is running
if pgrep -x "waybar" > /dev/null; then
    echo "Killing waybar..."
    killall -9 waybar
else
    echo "Starting waybar..."
    waybar &
fi
