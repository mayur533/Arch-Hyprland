#!/usr/bin/env python3
import json
import subprocess
from datetime import datetime

def safe_run(cmd):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL).decode().strip()
    except:
        return ""

def get_players():
    players = safe_run(["playerctl", "-l"]).splitlines()
    return players if players else []

def get_metadata(player):
    return {
        "text": safe_run(["playerctl", "-p", player, "metadata", "xesam:title"]) or "No Media",
        "artist": safe_run(["playerctl", "-p", player, "metadata", "xesam:artist"]) or "Unknown Artist",
        "album": safe_run(["playerctl", "-p", player, "metadata", "xesam:album"]) or "Unknown Album",
        "length": int(safe_run(["playerctl", "-p", player, "metadata", "mpris:length"]) or 0) // 1000000,
        "position": int(float(safe_run(["playerctl", "-p", player, "position"]) or 0)),
        "state": safe_run(["playerctl", "-p", player, "status"]).lower(),
        "player": player,
        "icon": "" if safe_run(["playerctl", "-p", player, "status"]).lower() == "paused" else ""
    }

def format_time(seconds):
    return f"{seconds // 60}:{seconds % 60:02d}" if seconds > 0 else "0:00"

def main():
    players = get_players()
    
    if not players:
        print(json.dumps({
            "text": " No Media",
            "tooltip": "No active media player detected",
            "class": "no-media",
            "alt": "no-media"
        }))
        return
    
    meta = get_metadata(players[0])
    time_info = f" ({format_time(meta['position'])}/{format_time(meta['length'])})" if meta["length"] > 0 else ""
    
    print(json.dumps({
        "text": f"{meta['icon']} {meta['text'][:25]}{time_info}",
        "tooltip": (
            f"🎵 <b>{meta['text']}</b>\n"
            f"👤 {meta['artist']}\n"
            f"💽 {meta['album']}\n"
            f"⏱ {format_time(meta['position'])}/{format_time(meta['length'])}\n"
            f"\nPlayer: {meta['player']}\n"
            f"Status: {meta['state'].title()}\n"
            f"Updated: {datetime.now().strftime('%H:%M:%S')}"
        ),
        "class": meta["state"],
        "alt": meta["state"]
    }))

if __name__ == "__main__":
    main()