#!/bin/bash

addr="$1"
[ -z "$addr" ] && exit 1

# Use hyprctl dispatch to focus the window
hyprctl dispatch focuswindow address:$addr
