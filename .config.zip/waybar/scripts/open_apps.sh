#!/bin/bash

mapfile -t windows < <(hyprctl clients -j | jq -r '.[] | "\(.class) \(.address)"')

declare -A app_map
for entry in "${windows[@]}"; do
    class=$(awk '{print $1}' <<< "$entry")
    addr=$(awk '{print $2}' <<< "$entry")
    app_map[$class]=$addr
done

output="["
for class in "${!app_map[@]}"; do
    addr=${app_map[$class]}
    # Inline hyprctl dispatch command using bash -c
    onclick="bash -c 'hyprctl dispatch focuswindow address:$addr'"
    output+="{\"text\":\"$class\",\"tooltip\":\"$class\",\"class\":\"$class\",\"on-click\":\"$onclick\"},"
done
output="${output%,}]"

echo "$output"

